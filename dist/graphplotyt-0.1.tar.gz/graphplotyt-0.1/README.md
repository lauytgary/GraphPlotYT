# GraphPlotYT

Plot graph for backtest

## Installation
```bash
pip install GraphPlotYT